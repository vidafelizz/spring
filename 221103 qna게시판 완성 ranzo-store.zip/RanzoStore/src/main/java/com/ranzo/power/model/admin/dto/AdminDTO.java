package com.ranzo.power.model.admin.dto;

public class AdminDTO {

}
