package com.example.spring02.service.chart;

import org.jfree.chart.JFreeChart;

public interface JFreeChartService {
	public JFreeChart createChart();

}
