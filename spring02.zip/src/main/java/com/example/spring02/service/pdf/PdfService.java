package com.example.spring02.service.pdf;

public interface PdfService {
	public String createPdf();

}
