package com.example.spring01.service;

import java.util.List;

import com.example.spring01.model.dto.DeptVO;

public interface DeptService {
	public List<DeptVO> deptList();

}
