package com.ranzo.power.controller.qnaboard;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ranzo.power.model.qnaboard.dto.QnaBoardDTO;
import com.ranzo.power.service.qnaboard.QnaBoardService;

@Controller
@RequestMapping("qnaboard/*")
public class QnaBoardController {
	private static final Logger logger  = LoggerFactory.getLogger(QnaBoardController.class);

	@Inject
	QnaBoardService qnaboardService;
	
	@RequestMapping("list.do")
	public ModelAndView list() throws Exception {
		List<QnaBoardDTO> list = qnaboardService.listAll();
		//System.out.println(list);
		logger.info(list.toString());
		ModelAndView mav = new ModelAndView();
		Map<String,Object> map = new HashMap<>();
		map.put("list", list); //map에 자료 저장
		map.put("count", list.size()); //레코드 개수
		mav.setViewName("qnaboard/list"); //포워딩할 뷰
		mav.addObject("map", map); //보낼데이터
		return mav;
	}
	
	@RequestMapping("write.do")
	public String write() {
		return "qnaboard/write";
	}
	
	@RequestMapping("insert.do")
	public String insert(@ModelAttribute QnaBoardDTO dto, HttpSession session) throws Exception {
		//세션에서 사용자 아이디를 가져옴
		String userid=(String)session.getAttribute("userid");
		dto.setUserid(userid);
		//레코드 저장
		qnaboardService.create(dto);
		//게시물 목록으로 이동
		return "redirect:/qnaboard/list.do";
	}
}
