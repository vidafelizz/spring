package com.ranzo.power.model.qnaboard.dto;

import java.util.Arrays;
import java.util.Date;

public class QnaBoardDTO {
	private int bno; //게시글 번호
	private String product; //전시명
	private String userid; //작성자 id
	private String name; //작성자 이름
	private String title; //제목
	private String content; //내용 
	private Date reg_date; //작성일자 
	private String[] filename; //첨부파일 이름 배열
	private int cnt; //댓글 개수
	private String show; //화면표시 여부
	private int viewcnt; //조회수
	
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getReg_date() {
		return reg_date;
	}
	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}
	public String[] getFilename() {
		return filename;
	}
	public void setFilename(String[] filename) {
		this.filename = filename;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public String getShow() {
		return show;
	}
	public void setShow(String show) {
		this.show = show;
	}
	public int getViewcnt() {
		return viewcnt;
	}
	public void setViewcnt(int viewcnt) {
		this.viewcnt = viewcnt;
	}
	@Override
	public String toString() {
		return "QnaBoardDTO [bno=" + bno + ", product=" + product + ", userid=" + userid + ", name=" + name + ", title="
				+ title + ", content=" + content + ", reg_date=" + reg_date + ", filename=" + Arrays.toString(filename)
				+ ", cnt=" + cnt + ", show=" + show + ", viewcnt=" + viewcnt + "]";
	}

}
