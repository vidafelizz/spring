package com.example.album.model.shop.dto;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

public class ProductDTO {	
	private int product_id; //상품번호
	private String picture_url; //썸네일
	private String product_name; //상품명
	private String product_artist; //아티스트
	private int price; //가격
	private String description; //본문설명
	private Date pubdate; //발매일
	private MultipartFile file1; //첨부파일
	
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getPicture_url() {
		return picture_url;
	}
	public void setPicture_url(String picture_url) {
		this.picture_url = picture_url;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getProduct_artist() {
		return product_artist;
	}
	public void setProduct_artist(String product_artist) {
		this.product_artist = product_artist;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getPubdate() {
		return pubdate;
	}
	public void setPubdate(Date pubdate) {
		this.pubdate = pubdate;
	}
	public MultipartFile getFile1() {
		return file1;
	}
	public void setFile1(MultipartFile file1) {
		this.file1 = file1;
	}
	@Override
	public String toString() {
		return "ProductDTO [product_id=" + product_id + ", picture_url=" + picture_url + ", product_name="
				+ product_name + ", product_artist=" + product_artist + ", price=" + price + ", description="
				+ description + ", pubdate=" + pubdate + ", file1=" + file1 + "]";
	}
}
